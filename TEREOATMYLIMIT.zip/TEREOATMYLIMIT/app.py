from flask import Flask, render_template, request, redirect, session
import sqlite3
from sqlite3 import Error
from flask_bcrypt import Bcrypt
from datetime import datetime

app = Flask(__name__)
bcrypt = Bcrypt(app)
app.secret_key = "itslikethisandlikethatandlikethisandum"
DATABASE = "C:/Users/admin/PycharmProjects/TEREOATMYLIMIT/identifier.sqlite"


# Function to create a connection to the SQLite database
def create_connection(db_file):
    try:
        connection = sqlite3.connect(db_file)
        return connection
    except Error as error:
        print(error)
    return None


# Function to open a connection to the database
def open_database(database):
    return sqlite3.connect(database)


# Function to check if a user is logged in
def is_logged_in():
    if session.get("email") is None:
        print("not logged in")
        return False
    else:
        print("logged in")
        return True


# Function to check if a user is a teacher
def is_teacher():
    if session.get("teacher") is None:
        print("not teacher")
        return False
    else:
        print("teacher")
        return True


# Route to render the homepage
@app.route('/')
def render_homepage():
    print(session)
    return render_template('home.html', logged_in=is_logged_in(), teacher=is_teacher())


# Route to handle the dictionary page
@app.route('/dictionary', methods=['GET', 'POST'])
def dictionary():
    if request.method == 'POST':
        # Handle deletion of a word
        word_id = request.form.get('Word_id')
        print(word_id)
        query = 'DELETE FROM Singular WHERE Singular.Word_Id = ?'
        con = create_connection(DATABASE)
        cur = con.cursor()
        cur.execute(query, (word_id,))
        con.commit()
        con.close()
        return redirect('/dictionary?error=Deleted')

    # Retrieve word list and category data from the database
    con = create_connection(DATABASE)
    query = "SELECT Word_Id, Maori, English, Category, Definition, Level, fname, Date_Entry FROM Singular w " \
            "INNER JOIN Users u ON w.User_ID = u.Id INNER JOIN Category c ON w.Cat_id = c.Id"
    cur = con.cursor()
    cur.execute(query)
    word_list = cur.fetchall()
    con.close()
    con = create_connection(DATABASE)
    query = "SELECT * FROM Category"
    cur = con.cursor()
    cur.execute(query)
    category = cur.fetchall()
    con.close()
    print(word_list)
    return render_template('dictionary.html', categories=category, words=word_list, logged_in=is_logged_in(),
                           teacher=is_teacher())


# Route to handle user login
@app.route("/login", methods=['POST', 'GET'])
def login():
    if is_logged_in():
        return redirect("/")
    if request.method == 'POST':
        email_user = request.form['email'].strip().lower()
        password = request.form['password'].strip()
        query = "SElECT Id, fname, password,teacher FROM Users WHERE email = ?"
        con = open_database(DATABASE)
        cur = con.cursor()
        cur.execute(query, (email_user,))
        user_data = cur.fetchall()
        con.close()

        if user_data is None:
            return redirect("/login?error=Email+invalid+password+incorrect")

        try:
            user_id = user_data[0][0]
            name = user_data[0][1]
            db_password = user_data[0][2]
            teacher = user_data[0][3]

        except IndexError:
            return redirect("/login?error=Email+invalid+password+incorrect")

        if not bcrypt.check_password_hash(db_password, password):
            return redirect(request.referrer + "?error=Email+invalid+or+password+incorrect")

        session['email'] = email_user
        session['Id'] = user_id
        session['fname'] = name
        session['teacher'] = teacher
        print(session)
        return redirect('/')
    return render_template('login.html', logged_in=is_logged_in(), teacher=is_teacher())


# Route to handle user logout
@app.route('/logout')
def logout():
    print(list(session.keys()))
    [session.pop(key) for key in list(session.keys())]
    print(list(session.keys()))
    return redirect('/?message=See+you+next+time!')


# Route to render the signup page and handle user signup
@app.route('/signup', methods=['POST', 'GET'])
def render_signup_page():
    if request.method == 'POST':
        print(request.form)
        f_name = request.form.get('fname').title().strip()
        l_name = request.form.get('lname').title().strip()
        email_user = request.form.get('email').lower().strip()
        password_user = request.form.get('password')
        password2 = request.form.get('password2')
        teacher = request.form.get('teacher')

        if password_user != password2:
            print(f'password1: {password_user}, password2: {password2}')
            return redirect("/signup?error=Passwords+do+not+match")

        if len(password_user) < 8:
            return redirect("/signup?error=Password+must+be+at+least+8+letters")

        hashed_password = bcrypt.generate_password_hash(password_user)
        con = open_database(DATABASE)
        query = 'INSERT INTO Users (fname, lname, email, password, teacher) VALUES (?, ?, ?, ?, ?)'
        cur = con.cursor()
        try:
            cur.execute(query, (f_name, l_name, email_user, hashed_password, teacher))
            con.commit()
        except sqlite3.IntegrityError:
            con.close()
            return redirect("/signup?error=Email+is+all+ready+in+use")

    return render_template('signup.html', logged_in=is_logged_in(), teacher=is_teacher())


# Route to render the admin page and handle word addition
@app.route('/admin', methods=['POST', 'GET'])
def render_admin():
    if request.method == 'POST':
        print(request.form)
        maori = request.form.get('maori').capitalize().strip()
        english = request.form.get('english').capitalize().strip()
        category = request.form.get('category')
        definition = request.form.get('definition').capitalize()
        level = request.form.get('level')
        user_id = session.get('Id')
        image = 'noimage'
        date_entry = datetime.today().strftime("%d-%m-%Y")
        con = open_database(DATABASE)
        query = ('INSERT INTO Singular (Maori, English, Definition, Level,  Cat_id, User_id, Date_Entry) '
                 'VALUES (?, ?, ?, ?, ?, ?, ?)')
        cur = con.cursor()
        try:
            cur.execute(query, (maori, english, definition, level, category, user_id, date_entry))
            con.commit()
        except sqlite3.IntegrityError:
            con.close()
            return redirect("/admin?error=no")
    con = open_database(DATABASE)
    query = "SELECT * FROM Category"
    cur = con.cursor()
    cur.execute(query)
    category = cur.fetchall()
    con.close()
    print(category)
    return
